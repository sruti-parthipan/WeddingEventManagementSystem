package com.ey.exception;

public class NoClientsFoundException extends RuntimeException {
public NoClientsFoundException(String message) {
    super(message);

}
}
