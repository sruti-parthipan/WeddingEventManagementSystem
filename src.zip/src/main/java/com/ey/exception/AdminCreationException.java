package com.ey.exception;

public class AdminCreationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AdminCreationException(String message) {
		super(message);
	}

}
