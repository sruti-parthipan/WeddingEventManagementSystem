package com.ey.exception;

public class AdminLoginException extends RuntimeException {
public  AdminLoginException(String message) {
	super(message);
}
}
