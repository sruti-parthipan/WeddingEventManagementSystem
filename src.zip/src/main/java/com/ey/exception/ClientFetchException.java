package com.ey.exception;





public class ClientFetchException extends RuntimeException {
    public ClientFetchException(String message) {
        super(message);
    }
}
