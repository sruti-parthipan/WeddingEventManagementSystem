package com.ey.exception;

public class ReviewCreationException extends RuntimeException {
	public ReviewCreationException(String message) { super(message); }

}
