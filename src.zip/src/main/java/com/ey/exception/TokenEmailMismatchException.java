package com.ey.exception;

public class TokenEmailMismatchException extends RuntimeException {
	public TokenEmailMismatchException(String message) { super(message); }
}
