package com.ey.exception;

public class EventNotFoundException extends RuntimeException {

public EventNotFoundException(String message) {
        super(message);
    }

}
