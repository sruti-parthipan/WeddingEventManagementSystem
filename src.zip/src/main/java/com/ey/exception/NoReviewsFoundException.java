package com.ey.exception;

public class NoReviewsFoundException extends RuntimeException {
	public NoReviewsFoundException(String message) { super(message); }
}
