
package com.ey.exception;
public class EventDeleteException extends RuntimeException {
    public EventDeleteException(String message) { super(message); }
}
