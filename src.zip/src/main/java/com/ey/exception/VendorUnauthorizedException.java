
	package com.ey.exception;
	public class VendorUnauthorizedException extends RuntimeException {
	    public VendorUnauthorizedException(String message) { super(message); }
	}


