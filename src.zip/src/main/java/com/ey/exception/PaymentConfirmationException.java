package com.ey.exception;

public class PaymentConfirmationException extends RuntimeException {
	public PaymentConfirmationException(String message) { super(message); }
}
