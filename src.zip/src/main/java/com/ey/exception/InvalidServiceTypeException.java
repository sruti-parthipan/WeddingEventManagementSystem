

package com.ey.exception;
public class InvalidServiceTypeException extends RuntimeException {
    public InvalidServiceTypeException(String message) { super(message); }
}
