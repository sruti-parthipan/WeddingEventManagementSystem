
package com.ey.exception;

public class NoVendorsFoundException extends RuntimeException {
 public NoVendorsFoundException(String message) {
     super(message);
 }
}
