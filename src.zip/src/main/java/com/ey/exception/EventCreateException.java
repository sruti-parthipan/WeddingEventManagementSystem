

package com.ey.exception;
public class EventCreateException extends RuntimeException {
    public EventCreateException(String message) { super(message); }
}
