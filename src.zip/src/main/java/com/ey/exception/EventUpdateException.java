

package com.ey.exception;
public class EventUpdateException extends RuntimeException {
    public EventUpdateException(String message) { super(message); }
}
