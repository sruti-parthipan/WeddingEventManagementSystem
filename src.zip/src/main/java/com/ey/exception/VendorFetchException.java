package com.ey.exception;


public class VendorFetchException extends RuntimeException {
    public VendorFetchException(String message) {
        super(message);
    }
}
