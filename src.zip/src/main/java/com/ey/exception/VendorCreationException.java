package com.ey.exception;

public class VendorCreationException extends RuntimeException {
public VendorCreationException(String message) {
	super(message);
}
}
