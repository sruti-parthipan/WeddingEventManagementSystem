

//PaymentNotFoundException.java
package com.ey.exception;
public class PaymentNotFoundException extends RuntimeException {
 public PaymentNotFoundException(String message) { super(message); }
}
