package com.ey.exception;

public class ClientCreationException extends RuntimeException {

	 public ClientCreationException(String message) {
	        super(message);
	    }

}
