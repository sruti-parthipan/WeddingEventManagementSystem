package com.ey.exception;

public class NoRatingsFoundException extends RuntimeException {

    public NoRatingsFoundException(String message) { super(message); }

}
