package com.ey.enums;

public enum ServiceType {

	CATERING, DECORATION, PHOTOGRAPHY, MUSIC, VENUE, TRANSPORT

}
