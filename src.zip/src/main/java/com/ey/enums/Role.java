package com.ey.enums;

public enum Role {

	ADMIN, CLIENT, VENDOR

}
