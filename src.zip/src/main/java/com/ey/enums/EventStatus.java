package com.ey.enums;

public enum EventStatus {

	PLANNED, COMPLETED, CONFIRMED, CANCELLED, IN_PROGRESS

}
