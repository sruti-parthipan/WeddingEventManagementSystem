package com.ey.enums;

public enum BookingStatus {
	REQUESTED, CONFIRMED, IN_PROGRESS, COMPLETED, CANCELLED
}
