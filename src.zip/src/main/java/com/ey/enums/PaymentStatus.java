package com.ey.enums;

public enum PaymentStatus {
	PENDING, SUCCESS, FAILED, REFUNDED
}
