package com.ey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeddingEventManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
